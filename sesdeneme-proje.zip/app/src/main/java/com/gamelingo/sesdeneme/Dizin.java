package com.gamelingo.sesdeneme;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Ses paketinin dizini. Satir tabanli, bagimliliksiz.
 *
 * Baslik:  # GameLingo ses paketi 1 \t SAHNE \t ORNEKLEME \t SAYI
 * Satir:   anahtar \t anahtarlar(virgul) \t dosya \t kim \t ton \t sure \t tr \t en
 */
public final class Dizin {

    public static final class Kayit {
        public final String anahtar;
        public final String[] anahtarlar;
        public final String dosya;
        public final String kim;
        public final String ton;
        public final float sure;
        public final String tr;
        public final String en;

        Kayit(String anahtar, String[] anahtarlar, String dosya, String kim,
              String ton, float sure, String tr, String en) {
            this.anahtar = anahtar;
            this.anahtarlar = anahtarlar;
            this.dosya = dosya;
            this.kim = kim;
            this.ton = ton;
            this.sure = sure;
            this.tr = tr;
            this.en = en;
        }
    }

    public String sahne = "?";
    public int ornekleme = 48000;
    public final List<Kayit> kayitlar = new ArrayList<>();
    private final Map<String, Kayit> harita = new HashMap<>();

    /** Anahtarla arar; devam satirlarinin anahtari da ayni kayda cikar. */
    public Kayit bul(String anahtar) {
        return anahtar == null ? null : harita.get(anahtar);
    }

    /** Ekrandaki Ingilizce metinden arar (ad onceden ayrilmis olmali). */
    public Kayit bulMetin(String ingilizce) {
        return bul(PaketAnahtari.hesapla(ingilizce));
    }

    /** Paketteki konusmaci adlari. */
    public java.util.Set<String> adlar() {
        java.util.Set<String> k = new java.util.LinkedHashSet<>();
        for (Kayit x : kayitlar) if (!x.kim.isEmpty()) k.add(x.kim);
        return k;
    }

    /** OCR sonucunun tamami: once ad ayrilir, sonra anahtar hesaplanir. */
    public static final class Eslesme {
        /** Ekrandan okunan konusmaci adi; yoksa null. */
        public final String ad;
        /** Addan arindirilmis replik -- anahtar bundan hesaplandi. */
        public final String metin;
        /** Pakette bulunan kayit; yoksa null. */
        public final Kayit kayit;

        Eslesme(String ad, String metin, Kayit kayit) {
            this.ad = ad;
            this.metin = metin;
            this.kayit = kayit;
        }

        public boolean var() {
            return kayit != null;
        }
    }

    /**
     * Oyunda yapilacak is tam bu: OCR satirini al, varsa konusmaci adini ayir,
     * kalan metnin anahtarini hesapla, pakette ara.
     */
    public Eslesme bulOcr(String ocrSatiri) {
        KonusmaciAyirici.Sonuc a = KonusmaciAyirici.ayir(ocrSatiri, adlar());
        Kayit k = bulMetin(a.metin);
        if (k == null && a.bulundu()) {
            // ad yanlis ayrilmis olabilir: ham satirla da dene
            k = bulMetin(ocrSatiri);
            if (k != null) return new Eslesme(null, ocrSatiri == null ? "" : ocrSatiri.trim(), k);
        }
        return new Eslesme(a.ad, a.metin, k);
    }

    public int boyut() {
        return kayitlar.size();
    }

    public static Dizin oku(BufferedReader r) throws IOException {
        Dizin d = new Dizin();
        String satir;
        int no = 0;
        while ((satir = r.readLine()) != null) {
            no++;
            if (satir.isEmpty()) continue;
            if (satir.charAt(0) == '#') {
                String[] b = satir.split("\t", -1);
                if (b.length >= 4) {
                    d.sahne = b[1];
                    try {
                        d.ornekleme = Integer.parseInt(b[2].trim());
                    } catch (NumberFormatException ignored) { }
                }
                continue;
            }
            String[] a = satir.split("\t", -1);
            if (a.length < 7) {
                throw new IOException("dizin.tsv " + no + ". satirda " + a.length
                        + " alan var, en az 7 olmali");
            }
            float sure;
            try {
                sure = Float.parseFloat(a[5]);
            } catch (NumberFormatException e) {
                sure = 0f;
            }
            String[] anahtarlar = a[1].isEmpty() ? new String[]{a[0]} : a[1].split(",");
            Kayit k = new Kayit(a[0], anahtarlar, a[2], a[3], a[4], sure,
                    a[6], a.length > 7 ? a[7] : "");
            d.kayitlar.add(k);
            for (String an : anahtarlar) {
                an = an.trim();
                if (!an.isEmpty() && !d.harita.containsKey(an)) d.harita.put(an, k);
            }
            if (!d.harita.containsKey(k.anahtar)) d.harita.put(k.anahtar, k);
        }
        return d;
    }
}
