package com.gamelingo.sesdeneme;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * GameLingo ses paketi deneme uygulamasi.
 *
 * Ne yapar:
 *   1. Colab'den indirdigin sespaketi_*.zip dosyasini acar.
 *   2. Icindeki dizin.tsv'yi okur, repliklerin listesini gosterir.
 *   3. Listeden dokundugun repligi calar.
 *   4. Ustteki kutuya ekrandaki Ingilizce altyaziyi yazarsan, paket anahtarini
 *      hesaplayip eslesen sesi calar  --  uygulamanin oyunda yapacagi is tam bu.
 */
public class MainActivity extends Activity {

    private static final int SEC_ZIP = 1;

    private TextView durum;
    private EditText kutu;
    private ListView liste;
    private ArrayAdapter<String> uyarlayici;

    private Dizin dizin;
    private File klasor;
    private MediaPlayer calar;
    private final List<String> satirlar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        klasor = new File(getFilesDir(), "paket");

        LinearLayout kok = new LinearLayout(this);
        kok.setOrientation(LinearLayout.VERTICAL);
        int p = dp(12);
        kok.setPadding(p, p, p, p);

        TextView baslik = new TextView(this);
        baslik.setText("GameLingo — Ses Paketi Denemesi");
        baslik.setTypeface(Typeface.DEFAULT_BOLD);
        baslik.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        kok.addView(baslik);

        durum = new TextView(this);
        durum.setText("Paket yok. Once Colab'den indirdigin zip'i sec.");
        durum.setPadding(0, dp(6), 0, dp(10));
        kok.addView(durum);

        Button sec = new Button(this);
        sec.setText("Paket seç (zip)");
        sec.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { zipSec(); }
        });
        kok.addView(sec);

        kutu = new EditText(this);
        kutu.setHint("Altyazıyı olduğu gibi yaz: JASON: Get in the water!");
        kutu.setSingleLine(false);
        kok.addView(kutu);

        Button ara = new Button(this);
        ara.setText("Anahtarı hesapla ve çal");
        ara.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { metinAra(); }
        });
        kok.addView(ara);

        liste = new ListView(this);
        uyarlayici = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, satirlar);
        liste.setAdapter(uyarlayici);
        liste.setOnItemClickListener((parent, view, position, id) -> {
            if (dizin != null && position < dizin.boyut()) cal(dizin.kayitlar.get(position));
        });
        kok.addView(liste, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(kok);

        if (new File(klasor, "dizin.tsv").exists()) dizinYukle();
    }

    private int dp(int d) {
        return (int) (d * getResources().getDisplayMetrics().density);
    }

    // ---- zip secme ve acma -------------------------------------------------

    private void zipSec() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, SEC_ZIP);
        } catch (Exception e) {
            durum.setText("Dosya seçici açılamadı: " + e);
        }
    }

    @Override
    protected void onActivityResult(int istek, int sonuc, Intent veri) {
        super.onActivityResult(istek, sonuc, veri);
        if (istek != SEC_ZIP || sonuc != RESULT_OK || veri == null || veri.getData() == null) return;
        zipAc(veri.getData());
    }

    private void zipAc(Uri uri) {
        durum.setText("Paket açılıyor...");
        sil(klasor);
        if (!klasor.mkdirs() && !klasor.isDirectory()) {
            durum.setText("Klasör oluşturulamadı.");
            return;
        }
        int sayi = 0;
        try (InputStream gir = getContentResolver().openInputStream(uri)) {
            if (gir == null) throw new IOException("zip okunamadi");
            ZipInputStream z = new ZipInputStream(gir);
            ZipEntry e;
            byte[] tampon = new byte[32 * 1024];
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) { z.closeEntry(); continue; }
                String ad = new File(e.getName()).getName();   // yol atlatmasini engeller
                if (ad.isEmpty() || ad.startsWith(".")) { z.closeEntry(); continue; }
                File hedef = new File(klasor, ad);
                try (FileOutputStream cik = new FileOutputStream(hedef)) {
                    int n;
                    while ((n = z.read(tampon)) > 0) cik.write(tampon, 0, n);
                }
                sayi++;
                z.closeEntry();
            }
            z.close();
        } catch (Exception ex) {
            durum.setText("Zip açılamadı: " + ex);
            return;
        }
        if (!new File(klasor, "dizin.tsv").exists()) {
            durum.setText("Zip içinde dizin.tsv yok. Bu paket eski sürüm olabilir — "
                    + "defteri tekrar çalıştırıp yeni zip al.");
            return;
        }
        Toast.makeText(this, sayi + " dosya açıldı", Toast.LENGTH_SHORT).show();
        dizinYukle();
    }

    private void dizinYukle() {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new java.io.FileInputStream(new File(klasor, "dizin.tsv")),
                StandardCharsets.UTF_8))) {
            dizin = Dizin.oku(r);
        } catch (Exception e) {
            durum.setText("dizin.tsv okunamadı: " + e);
            return;
        }
        satirlar.clear();
        int eksik = 0;
        for (int i = 0; i < dizin.boyut(); i++) {
            Dizin.Kayit k = dizin.kayitlar.get(i);
            boolean var = new File(klasor, k.dosya).exists();
            if (!var) eksik++;
            satirlar.add(String.format("%02d  %s · %s%s%n%s", i + 1, k.kim, k.ton,
                    var ? "" : "  [ses dosyasi yok]", k.tr));
        }
        uyarlayici.notifyDataSetChanged();
        durum.setText(String.format("%s — %d replik yüklü%s%nListeden dokunup dinle.",
                dizin.sahne, dizin.boyut(), eksik > 0 ? ", " + eksik + " ses dosyasi eksik" : ""));
    }

    private static void sil(File f) {
        if (f == null || !f.exists()) return;
        File[] ic = f.listFiles();
        if (ic != null) for (File x : ic) sil(x);
        f.delete();
    }

    // ---- arama ve calma ---------------------------------------------------

    private void metinAra() {
        if (dizin == null) { durum.setText("Önce paket seç."); return; }
        String satir = kutu.getText().toString();
        if (TextUtils.isEmpty(satir.trim())) { durum.setText("Kutu boş."); return; }

        // Oyunda yapilacak is tam bu zincir: ad ayir -> anahtar hesapla -> pakette ara.
        Dizin.Eslesme e = dizin.bulOcr(satir);
        StringBuilder b = new StringBuilder();
        b.append("Okunan ad: ").append(e.ad == null ? "—" : e.ad).append('\n');
        b.append("Aranan metin: ").append(e.metin).append('\n');
        b.append("Anahtar: ").append(PaketAnahtari.hesapla(e.metin)).append('\n');

        if (!e.var()) {
            b.append("Pakette eşleşme yok.");
            durum.setText(b.toString());
            return;
        }
        Dizin.Kayit k = e.kayit;
        b.append("Eşleşti → ").append(k.kim).append(" · ").append(k.ton);
        if (e.ad != null && !KonusmaciAyirici.sade(e.ad).equals(KonusmaciAyirici.sade(k.kim))) {
            b.append("  (ekrandaki ad pakettekinden farklı)");
        }
        b.append('\n').append(k.tr);
        durum.setText(b.toString());
        cal(k);
    }

    private void cal(Dizin.Kayit k) {
        File f = new File(klasor, k.dosya);
        if (!f.exists()) {
            durum.setText("Ses dosyası yok: " + k.dosya);
            return;
        }
        dur();
        try {
            calar = new MediaPlayer();
            calar.setDataSource(f.getAbsolutePath());
            calar.prepare();
            calar.start();
            durum.setText(k.kim + " · " + k.ton + "  (" + k.sure + " sn)\n" + k.tr);
        } catch (Exception e) {
            durum.setText("Çalınamadı: " + e);
        }
    }

    private void dur() {
        if (calar != null) {
            try { calar.stop(); } catch (Exception ignored) { }
            calar.release();
            calar = null;
        }
    }

    @Override
    protected void onDestroy() {
        dur();
        super.onDestroy();
    }
}
