package com.gamelingo.sesmotoru;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Kucuk bir RIFF/WAVE okuyucu. Sadece PCM 16 bit destekler -- urettigimiz
 * paketler zaten oyle. Bagimlilik yok, bu yuzden masaustunde de test edilebilir.
 */
public final class WavOkuyucu {

    public static final class Ses {
        public final byte[] pcm;      // little-endian 16 bit
        public final int ornekleme;   // Hz
        public final int kanal;

        Ses(byte[] pcm, int ornekleme, int kanal) {
            this.pcm = pcm;
            this.ornekleme = ornekleme;
            this.kanal = kanal;
        }

        public float saniye() {
            return pcm.length / 2f / kanal / ornekleme;
        }
    }

    private WavOkuyucu() {}

    private static int u16(byte[] b, int i) {
        return (b[i] & 0xff) | ((b[i + 1] & 0xff) << 8);
    }

    private static int u32(byte[] b, int i) {
        return (b[i] & 0xff) | ((b[i + 1] & 0xff) << 8)
                | ((b[i + 2] & 0xff) << 16) | ((b[i + 3] & 0xff) << 24);
    }

    public static Ses oku(InputStream gir) throws IOException {
        byte[] ham = hepsi(gir);
        if (ham.length < 44) throw new IOException("wav cok kisa: " + ham.length);
        if (!(ham[0] == 'R' && ham[1] == 'I' && ham[2] == 'F' && ham[3] == 'F'))
            throw new IOException("RIFF basligi yok");
        if (!(ham[8] == 'W' && ham[9] == 'A' && ham[10] == 'V' && ham[11] == 'E'))
            throw new IOException("WAVE degil");

        int ornekleme = 0, kanal = 0, bit = 0;
        boolean fmtVar = false;
        int i = 12;
        while (i + 8 <= ham.length) {
            String tur = "" + (char) ham[i] + (char) ham[i + 1] + (char) ham[i + 2] + (char) ham[i + 3];
            int boy = u32(ham, i + 4);
            int veri = i + 8;
            if (boy < 0 || veri + boy > ham.length) boy = ham.length - veri;   // bozuk boy
            if ("fmt ".equals(tur)) {
                if (boy < 16) throw new IOException("fmt parcasi kisa");
                int bicim = u16(ham, veri);
                kanal = u16(ham, veri + 2);
                ornekleme = u32(ham, veri + 4);
                bit = u16(ham, veri + 14);
                if (bicim != 1 && bicim != 0xFFFE)
                    throw new IOException("sadece PCM destekleniyor, bicim=" + bicim);
                if (bit != 16) throw new IOException("sadece 16 bit destekleniyor, bit=" + bit);
                if (kanal < 1 || kanal > 2) throw new IOException("kanal=" + kanal);
                if (ornekleme < 4000 || ornekleme > 192000) throw new IOException("ornekleme=" + ornekleme);
                fmtVar = true;
            } else if ("data".equals(tur)) {
                if (!fmtVar) throw new IOException("data'dan once fmt yok");
                byte[] pcm = new byte[boy - (boy % 2)];
                System.arraycopy(ham, veri, pcm, 0, pcm.length);
                return new Ses(pcm, ornekleme, kanal);
            }
            i = veri + boy + (boy & 1);     // parcalar cift hizali
        }
        throw new IOException("data parcasi yok");
    }

    /** Iki kanali tek kanala indirir; TTS tek kanal ister. */
    public static byte[] tekKanal(Ses s) {
        if (s.kanal == 1) return s.pcm;
        int n = s.pcm.length / 4;
        byte[] cik = new byte[n * 2];
        for (int k = 0; k < n; k++) {
            int sol = (short) u16(s.pcm, k * 4);
            int sag = (short) u16(s.pcm, k * 4 + 2);
            int o = (sol + sag) / 2;
            cik[k * 2] = (byte) (o & 0xff);
            cik[k * 2 + 1] = (byte) ((o >> 8) & 0xff);
        }
        return cik;
    }

    private static byte[] hepsi(InputStream gir) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(1 << 16);
        byte[] t = new byte[8192];
        int n;
        while ((n = gir.read(t)) > 0) b.write(t, 0, n);
        return b.toByteArray();
    }
}
