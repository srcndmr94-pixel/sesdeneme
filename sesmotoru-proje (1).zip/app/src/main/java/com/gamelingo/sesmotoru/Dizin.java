package com.gamelingo.sesmotoru;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Ses paketinin dizini. Satir tabanli, bagimliliksiz.
 *
 * Baslik:  # GameLingo ses paketi 1 \t SAHNE \t ORNEKLEME \t SAYI
 * Satir:   anahtar \t anahtarlar(virgul) \t dosya \t kim \t ton \t sure \t tr \t en
 */
public final class Dizin {

    public static final class Kayit {
        public final String anahtar;
        public final String[] anahtarlar;
        public final String dosya;
        public final String kim;
        public final String ton;
        public final float sure;
        public final String tr;
        public final String en;

        Kayit(String anahtar, String[] anahtarlar, String dosya, String kim,
              String ton, float sure, String tr, String en) {
            this.anahtar = anahtar;
            this.anahtarlar = anahtarlar;
            this.dosya = dosya;
            this.kim = kim;
            this.ton = ton;
            this.sure = sure;
            this.tr = tr;
            this.en = en;
        }
    }

    public String sahne = "?";
    public int ornekleme = 48000;
    public final List<Kayit> kayitlar = new ArrayList<>();
    private final Map<String, Kayit> harita = new HashMap<>();
    /** Turkce metinden arama: TTS motoruna Ingilizce degil, cevrilmis metin gelir. */
    private final Map<String, Kayit> trHarita = new HashMap<>();

    /** Anahtarla arar; devam satirlarinin anahtari da ayni kayda cikar. */
    public Kayit bul(String anahtar) {
        return anahtar == null ? null : harita.get(anahtar);
    }

    /**
     * Metinden arar. Once Ingilizce anahtarina, tutmazsa Turkce anahtarina bakar.
     * Uygulama OCR'dan Ingilizce verir; TTS motoruna ise cevrilmis Turkce gelir.
     */
    public Kayit bulMetin(String metin) {
        String a = PaketAnahtari.hesapla(metin);
        if (a == null) return null;
        Kayit k = harita.get(a);
        return k != null ? k : trHarita.get(a);
    }

    /** Yalnizca Turkce metinden arar. */
    public Kayit bulTurkce(String turkce) {
        String a = PaketAnahtari.hesapla(turkce);
        return a == null ? null : trHarita.get(a);
    }

    /** Turkce karsiligi ayri anahtara dusen replik sayisi. */
    public int turkceAnahtarSayisi() {
        return trHarita.size();
    }

    /** Paketteki konusmaci adlari. */
    public java.util.Set<String> adlar() {
        java.util.Set<String> k = new java.util.LinkedHashSet<>();
        for (Kayit x : kayitlar) if (!x.kim.isEmpty()) k.add(x.kim);
        return k;
    }

    /** OCR sonucunun tamami: once ad ayrilir, sonra anahtar hesaplanir. */
    public static final class Eslesme {
        /** Ekrandan okunan konusmaci adi; yoksa null. */
        public final String ad;
        /** Addan arindirilmis replik -- anahtar bundan hesaplandi. */
        public final String metin;
        /** Pakette bulunan kayit; yoksa null. */
        public final Kayit kayit;

        Eslesme(String ad, String metin, Kayit kayit) {
            this.ad = ad;
            this.metin = metin;
            this.kayit = kayit;
        }

        public boolean var() {
            return kayit != null;
        }
    }

    /**
     * Oyunda yapilacak is tam bu: OCR satirini al, varsa konusmaci adini ayir,
     * kalan metnin anahtarini hesapla, pakette ara.
     */
    public Eslesme bulOcr(String ocrSatiri) {
        KonusmaciAyirici.Sonuc a = KonusmaciAyirici.ayir(ocrSatiri, adlar());
        Kayit k = bulMetin(a.metin);
        if (k == null) {
            // Ayirma yanlis olabilir. Ornegin "[panicked] Are you insane?" satirinda
            // parantez oyunun kendi metninin parcasi, anahtar onunla hesaplanmis.
            // Kirpilmis metin tutmazsa ham satirla da dene.
            String ham = ocrSatiri == null ? "" : ocrSatiri.trim();
            if (!ham.equals(a.metin)) {
                Kayit k2 = bulMetin(ham);
                if (k2 != null) return new Eslesme(null, ham, k2);
            }
        }
        return new Eslesme(a.ad, a.metin, k);
    }

    public int boyut() {
        return kayitlar.size();
    }

    public static Dizin oku(BufferedReader r) throws IOException {
        Dizin d = new Dizin();
        String satir;
        int no = 0;
        while ((satir = r.readLine()) != null) {
            no++;
            if (satir.isEmpty()) continue;
            if (satir.charAt(0) == '#') {
                String[] b = satir.split("\t", -1);
                if (b.length >= 4) {
                    d.sahne = b[1];
                    try {
                        d.ornekleme = Integer.parseInt(b[2].trim());
                    } catch (NumberFormatException ignored) { }
                }
                continue;
            }
            String[] a = satir.split("\t", -1);
            if (a.length < 7) {
                throw new IOException("dizin.tsv " + no + ". satirda " + a.length
                        + " alan var, en az 7 olmali");
            }
            float sure;
            try {
                sure = Float.parseFloat(a[5]);
            } catch (NumberFormatException e) {
                sure = 0f;
            }
            String[] anahtarlar = a[1].isEmpty() ? new String[]{a[0]} : a[1].split(",");
            Kayit k = new Kayit(a[0], anahtarlar, a[2], a[3], a[4], sure,
                    a[6], a.length > 7 ? a[7] : "");
            d.kayitlar.add(k);
            for (String an : anahtarlar) {
                an = an.trim();
                if (!an.isEmpty() && !d.harita.containsKey(an)) d.harita.put(an, k);
            }
            if (!d.harita.containsKey(k.anahtar)) d.harita.put(k.anahtar, k);
            if (!k.tr.isEmpty()) {
                String ta = PaketAnahtari.hesapla(k.tr);
                if (ta != null && !d.trHarita.containsKey(ta)) d.trHarita.put(ta, k);
            }
        }
        return d;
    }
}
