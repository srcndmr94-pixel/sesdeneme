package com.gamelingo.sesmotoru;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Paketi secip motoru kuran tek ekran. */
public class AyarActivity extends Activity {

    private static final int SEC_ZIP = 1;
    private TextView durum;
    private File klasor;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        klasor = new File(getFilesDir(), "paket");

        LinearLayout kok = new LinearLayout(this);
        kok.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (14 * getResources().getDisplayMetrics().density);
        kok.setPadding(p, p, p, p);

        TextView baslik = new TextView(this);
        baslik.setText("GameLingo Ses Motoru");
        baslik.setTypeface(Typeface.DEFAULT_BOLD);
        baslik.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        kok.addView(baslik);

        TextView anlat = new TextView(this);
        anlat.setText("1) Ses paketini seç.\n"
                + "2) Android Ayarlar ▸ Metin okuma çıkışı → "
                + "tercih edilen motor olarak \"GameLingo Ses Motoru\"nu seç.\n"
                + "3) GameLingo'yu aç. Pakette olan replikler doğal sesle, "
                + "olmayanlar Google sesiyle okunur.");
        anlat.setPadding(0, p / 2, 0, p);
        kok.addView(anlat);

        durum = new TextView(this);
        kok.addView(durum);

        Button sec = new Button(this);
        sec.setText("Ses paketi seç (zip)");
        sec.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { zipSec(); }
        });
        kok.addView(sec);

        Button ayar = new Button(this);
        ayar.setText("Metin okuma ayarlarını aç");
        ayar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    durum.setText("Ayar ekranı açılamadı. Ayarlar'da \"metin okuma\" diye ara.");
                }
            }
        });
        kok.addView(ayar);

        ScrollView s = new ScrollView(this);
        s.addView(kok, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(s);
        bildir();
    }

    private void zipSec() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, SEC_ZIP); }
        catch (Exception e) { durum.setText("Dosya seçici açılamadı: " + e); }
    }

    @Override
    protected void onActivityResult(int istek, int sonuc, Intent veri) {
        super.onActivityResult(istek, sonuc, veri);
        if (istek == SEC_ZIP && sonuc == RESULT_OK && veri != null && veri.getData() != null) {
            zipAc(veri.getData());
        }
    }

    private void zipAc(Uri uri) {
        durum.setText("Paket açılıyor...");
        sil(klasor);
        if (!klasor.mkdirs() && !klasor.isDirectory()) { durum.setText("Klasör kurulamadı."); return; }
        int n = 0;
        try (InputStream gir = getContentResolver().openInputStream(uri)) {
            ZipInputStream z = new ZipInputStream(gir);
            ZipEntry e;
            byte[] t = new byte[32768];
            while ((e = z.getNextEntry()) != null) {
                if (e.isDirectory()) { z.closeEntry(); continue; }
                String ad = new File(e.getName()).getName();
                if (ad.isEmpty() || ad.startsWith(".")) { z.closeEntry(); continue; }
                try (FileOutputStream c = new FileOutputStream(new File(klasor, ad))) {
                    int k;
                    while ((k = z.read(t)) > 0) c.write(t, 0, k);
                }
                n++;
                z.closeEntry();
            }
            z.close();
        } catch (Exception ex) {
            durum.setText("Zip açılamadı: " + ex);
            return;
        }
        bildir();
    }

    private void bildir() {
        File d = new File(klasor, "dizin.tsv");
        if (!d.exists()) { durum.setText("Paket yok. Önce bir zip seç."); return; }
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(d), StandardCharsets.UTF_8))) {
            Dizin dz = Dizin.oku(r);
            int eksik = 0;
            for (Dizin.Kayit k : dz.kayitlar) if (!new File(klasor, k.dosya).exists()) eksik++;
            durum.setText("Yüklü paket: " + dz.sahne + " · " + dz.boyut() + " replik · "
                    + dz.adlar().size() + " konuşmacı"
                    + (eksik > 0 ? " · " + eksik + " ses dosyası eksik" : ""));
        } catch (Exception e) {
            durum.setText("dizin.tsv okunamadı: " + e);
        }
    }

    private static void sil(File f) {
        if (f == null || !f.exists()) return;
        File[] i = f.listFiles();
        if (i != null) for (File x : i) sil(x);
        f.delete();
    }
}
