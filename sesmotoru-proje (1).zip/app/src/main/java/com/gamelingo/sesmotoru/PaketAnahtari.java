package com.gamelingo.sesmotoru;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.Locale;

/** GameLingo/CouchSubs paket anahtari. Python'daki anahtar() ile bire bir ayni olmali. */
public final class PaketAnahtari {

    private PaketAnahtari() {}

    public static String hesapla(String metin) {
        if (metin == null) return null;
        String s = metin;

        // 1) <...> etiketlerini at
        s = s.replaceAll("<[^>]*>", "");

        // 2) NFKC + kucuk harf (Locale.ROOT)
        s = Normalizer.normalize(s, Normalizer.Form.NFKC).toLowerCase(Locale.ROOT);

        // 3) NFD
        s = Normalizer.normalize(s, Normalizer.Form.NFD);

        // 4) birlesen isaretleri at
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int tur = Character.getType(c);
            if (tur == Character.NON_SPACING_MARK
                    || tur == Character.COMBINING_SPACING_MARK
                    || tur == Character.ENCLOSING_MARK) {
                continue;
            }
            b.append(c);
        }

        // 5) harf/rakam/bosluk disindaki her sey bosluk
        StringBuilder t = new StringBuilder(b.length());
        for (int i = 0; i < b.length(); i++) {
            char c = b.charAt(i);
            t.append((Character.isLetterOrDigit(c) || Character.isWhitespace(c)) ? c : ' ');
        }

        // 6) ardisik bosluklari tek bosluga indir, bastan sondan kirp
        s = t.toString().replaceAll("\\s+", " ").trim();

        // 7) SHA-256'nin ilk 8 bayti, 16 hex
        try {
            byte[] ozet = MessageDigest.getInstance("SHA-256")
                    .digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder h = new StringBuilder(16);
            for (int i = 0; i < 8; i++) h.append(String.format("%02x", ozet[i]));
            return h.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
