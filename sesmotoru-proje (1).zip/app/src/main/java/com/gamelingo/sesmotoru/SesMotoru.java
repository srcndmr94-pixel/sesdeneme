package com.gamelingo.sesmotoru;

import android.speech.tts.SynthesisCallback;
import android.speech.tts.SynthesisRequest;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeechService;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * GameLingo Ses Motoru -- bir Android TTS motoru.
 *
 * Gelen metni paket anahtarina cevirir. Pakette varsa onceden uretilmis dogal
 * sesi calar. Yoksa Google'in motoruna devreder, yani hicbir durumda bugunkunden
 * kotu olmaz.
 *
 * GameLingo kendi motorunu secmiyor, sistem varsayilanini kullaniyor. Bu yuzden
 * bu motor sistemde varsayilan yapilinca GameLingo kendiliginden bunu cagirir.
 */
public class SesMotoru extends TextToSpeechService {

    private static final String E = "GameLingoSes";
    private static final String GOOGLE = "com.google.android.tts";
    /** Devredilen sentez icin en fazla bekleme. */
    private static final long DEVIR_MS = 6000;

    private volatile Dizin dizin;
    private volatile File klasor;
    private volatile long dizinZaman;

    private TextToSpeech yedek;
    private final AtomicBoolean yedekHazir = new AtomicBoolean(false);
    private final AtomicBoolean durduruldu = new AtomicBoolean(false);

    @Override
    public void onCreate() {
        super.onCreate();
        klasor = new File(getFilesDir(), "paket");
        dizinTazele();
        yedek = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override public void onInit(int durum) {
                yedekHazir.set(durum == TextToSpeech.SUCCESS);
                Log.i(E, "yedek motor " + (yedekHazir.get() ? "hazir" : "yok"));
            }
        }, GOOGLE);
    }

    @Override
    public void onDestroy() {
        if (yedek != null) { yedek.shutdown(); yedek = null; }
        super.onDestroy();
    }

    /** Paket degismisse dizini yeniden oku. */
    private synchronized void dizinTazele() {
        File d = new File(klasor, "dizin.tsv");
        if (!d.exists()) { dizin = null; return; }
        if (dizin != null && d.lastModified() == dizinZaman) return;
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(new FileInputStream(d), StandardCharsets.UTF_8))) {
            dizin = Dizin.oku(r);
            dizinZaman = d.lastModified();
            Log.i(E, "paket yuklendi: " + dizin.sahne + " / " + dizin.boyut() + " replik");
        } catch (Exception e) {
            dizin = null;
            Log.w(E, "dizin okunamadi: " + e);
        }
    }

    // ---- TTS motoru sozlesmesi --------------------------------------------

    @Override
    protected String[] onGetLanguage() {
        return new String[]{"tur", "TUR", ""};
    }

    @Override
    protected int onIsLanguageAvailable(String dil, String ulke, String varyant) {
        if ("tur".equalsIgnoreCase(dil) || "tr".equalsIgnoreCase(dil)) {
            return TextToSpeech.LANG_AVAILABLE;
        }
        // Diger dillerde de devredecegimiz icin reddetmiyoruz.
        return TextToSpeech.LANG_AVAILABLE;
    }

    @Override
    protected int onLoadLanguage(String dil, String ulke, String varyant) {
        return onIsLanguageAvailable(dil, ulke, varyant);
    }

    @Override
    protected void onStop() {
        durduruldu.set(true);
        if (yedek != null) yedek.stop();
    }

    @Override
    protected synchronized void onSynthesizeText(SynthesisRequest istek, SynthesisCallback geri) {
        durduruldu.set(false);
        String metin = istek.getCharSequenceText() == null ? "" : istek.getCharSequenceText().toString();
        if (metin.trim().isEmpty()) { geri.start(24000, android.media.AudioFormat.ENCODING_PCM_16BIT, 1); geri.done(); return; }

        dizinTazele();
        WavOkuyucu.Ses ses = pakettenAl(metin);
        if (ses != null) {
            cal(geri, ses.pcm, ses.ornekleme, 1);
            return;
        }
        devret(metin, istek, geri);
    }

    /** Pakette eslesen hazir sesi getirir; yoksa null. */
    private WavOkuyucu.Ses pakettenAl(String metin) {
        Dizin d = dizin;
        if (d == null) return null;
        Dizin.Eslesme e = d.bulOcr(metin);
        if (!e.var()) return null;
        File f = new File(klasor, e.kayit.dosya);
        if (!f.exists()) return null;
        try (InputStream in = new FileInputStream(f)) {
            WavOkuyucu.Ses s = WavOkuyucu.oku(in);
            Log.i(E, "paketten: " + e.kayit.kim + " · " + e.kayit.ton + " · " + e.kayit.tr);
            return new WavOkuyucu.Ses(WavOkuyucu.tekKanal(s), s.ornekleme, 1);
        } catch (Exception ex) {
            Log.w(E, "wav okunamadi " + e.kayit.dosya + ": " + ex);
            return null;
        }
    }

    /** Pakette yoksa Google'in motoruna yaptir, ciktisini aktar. */
    private void devret(String metin, SynthesisRequest istek, SynthesisCallback geri) {
        if (!yedekHazir.get()) { sessiz(geri); return; }
        File gecici = new File(getCacheDir(), "devir.wav");
        if (gecici.exists() && !gecici.delete()) { sessiz(geri); return; }
        try {
            yedek.setLanguage(new Locale(
                    istek.getLanguage() == null ? "tr" : istek.getLanguage(),
                    istek.getCountry() == null ? "TR" : istek.getCountry()));
            float hiz = istek.getSpeechRate() / 100f;
            float perde = istek.getPitch() / 100f;
            if (hiz > 0) yedek.setSpeechRate(hiz);
            if (perde > 0) yedek.setPitch(perde);

            final CountDownLatch bekle = new CountDownLatch(1);
            final AtomicBoolean oldu = new AtomicBoolean(false);
            yedek.setOnUtteranceProgressListener(
                    new android.speech.tts.UtteranceProgressListener() {
                        @Override public void onStart(String id) { }
                        @Override public void onDone(String id) { oldu.set(true); bekle.countDown(); }
                        @Override public void onError(String id) { bekle.countDown(); }
                    });
            HashMap<String, String> p = new HashMap<>();
            p.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "gl");
            int s = yedek.synthesizeToFile(metin, p, gecici.getAbsolutePath());
            if (s != TextToSpeech.SUCCESS) { sessiz(geri); return; }
            if (!bekle.await(DEVIR_MS, TimeUnit.MILLISECONDS) || !oldu.get()) { sessiz(geri); return; }

            try (InputStream in = new FileInputStream(gecici)) {
                WavOkuyucu.Ses w = WavOkuyucu.oku(in);
                cal(geri, WavOkuyucu.tekKanal(w), w.ornekleme, 1);
            }
        } catch (Exception e) {
            Log.w(E, "devir basarisiz: " + e);
            sessiz(geri);
        } finally {
            gecici.delete();
        }
    }

    private void cal(SynthesisCallback geri, byte[] pcm, int ornekleme, int kanal) {
        geri.start(ornekleme, android.media.AudioFormat.ENCODING_PCM_16BIT, kanal);
        int enCok = Math.max(512, geri.getMaxBufferSize());
        int yer = 0;
        while (yer < pcm.length) {
            if (durduruldu.get()) { geri.done(); return; }
            int n = Math.min(enCok, pcm.length - yer);
            if (geri.audioAvailable(pcm, yer, n) != TextToSpeech.SUCCESS) { geri.done(); return; }
            yer += n;
        }
        geri.done();
    }

    private void sessiz(SynthesisCallback geri) {
        geri.start(24000, android.media.AudioFormat.ENCODING_PCM_16BIT, 1);
        geri.done();
    }
}
