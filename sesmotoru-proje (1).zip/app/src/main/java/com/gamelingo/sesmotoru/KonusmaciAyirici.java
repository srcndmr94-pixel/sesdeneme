package com.gamelingo.sesmotoru;

import java.text.Normalizer;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Ekrandaki altyazi satirindan konusmaci adini ayirir.
 *
 *   "JASON: Gir su suya lan!"  ->  ad="JASON", metin="Gir su suya lan!"
 *
 * Neden gerekli: paket anahtari repligin kendisinden hesaplaniyor, ad olmadan.
 * OCR ise adi da okuyor. Ad ayrilmazsa anahtar hicbir zaman eslesmez.
 *
 * Ayrac olarak once iki nokta aranir. OCR iki noktayi ';' '.' '|' 'i' gibi
 * okuyabildigi icin bunlar da kabul edilir, ama SADECE cikan ad pakette
 * bilinen bir konusmaciya denk gelirse -- yoksa "YEAH. Right." gibi normal
 * bir cumle yanlislikla bolunur.
 */
public final class KonusmaciAyirici {

    /** Adin arandigi ilk karakter sayisi. */
    private static final int SINIR = 24;
    /** Ad en fazla bu kadar karakter. */
    private static final int AD_EN_COK = 18;
    /** Ad en az bu kadar karakter. */
    private static final int AD_EN_AZ = 2;

    private static final char[] KESIN = {':'};
    /** "[Kregg] replik" ya da "(Kregg) replik" bicimi. */
    private static final java.util.regex.Pattern PARANTEZ =
            java.util.regex.Pattern.compile("^[\\[(]\\s*([^\\])]{1,24}?)\\s*[\\])]\\s*(.*)$");
    private static final char[] SUPHELI = {';', '|', '.', '·', '•'};

    public static final class Sonuc {
        /** Bulunan ad, ekranda yazdigi gibi. Bulunamazsa null. */
        public final String ad;
        /** Addan arindirilmis replik. Ad yoksa satirin kendisi. */
        public final String metin;

        Sonuc(String ad, String metin) {
            this.ad = ad;
            this.metin = metin;
        }

        public boolean bulundu() {
            return ad != null;
        }
    }

    private KonusmaciAyirici() {}

    /** Karsilastirma icin sadelestirir: Turkce harfler dahil. */
    public static String sade(String s) {
        if (s == null) return "";
        s = Normalizer.normalize(s, Normalizer.Form.NFKC).trim().toLowerCase(Locale.ROOT);
        s = s.replace('ı', 'i').replace('İ', 'i')
             .replace('ş', 's').replace('Ş', 's')
             .replace('ğ', 'g').replace('Ğ', 'g');
        s = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int t = Character.getType(c);
            if (t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK
                    || t == Character.ENCLOSING_MARK) continue;
            if (Character.isLetterOrDigit(c) || c == ' ') b.append(c);
            else if (Character.isWhitespace(c)) b.append(' ');
        }
        return b.toString().replaceAll("\\s+", " ").trim();
    }

    /** Bilinen ad listesi olmadan: sadece iki nokta ayracini kabul eder. */
    public static Sonuc ayir(String satir) {
        return ayir(satir, null);
    }

    /**
     * @param bilinenAdlar paketteki konusmaci adlari; supheli ayraclar yalnizca
     *                     bu listeden bir ada denk gelirse kabul edilir.
     */
    public static Sonuc ayir(String satir, Collection<String> bilinenAdlar) {
        if (satir == null) return new Sonuc(null, "");
        String s = satir.trim();
        if (s.isEmpty()) return new Sonuc(null, "");

        Set<String> bilinen = null;
        if (bilinenAdlar != null) {
            bilinen = new HashSet<>();
            for (String a : bilinenAdlar) bilinen.add(sade(a));
        }

        // 0) kosesli/yuvarlak parantezli on ek -- oyunlarin en yaygin bicimi.
        //    "[Kregg] The betrayer!" -> ad Kregg
        //    "[sighs] Stick to the plan." -> ses efekti, ad degil ama metinden atilir
        java.util.regex.Matcher pm = PARANTEZ.matcher(s);
        if (pm.matches()) {
            String ic = pm.group(1).trim();
            String kalan = pm.group(2).trim();
            if (!kalan.isEmpty() && ic.length() >= AD_EN_AZ && ic.length() <= AD_EN_COK) {
                boolean isim = Character.isUpperCase(ic.charAt(0));
                if (isim) {
                    int kelime = 1;
                    for (int i = 0; i < ic.length(); i++) if (ic.charAt(i) == ' ') kelime++;
                    if (kelime <= 3) return new Sonuc(ic, kalan);
                }
                // kucuk harfle basliyorsa ses efekti: adi yok, metinden cikar
                return new Sonuc(null, kalan);
            }
        }

        int son = Math.min(SINIR, s.length());

        // 1) kesin ayrac
        Sonuc r = dene(s, son, KESIN, null);
        if (r != null) return r;

        // 2) supheli ayrac, sadece bilinen ada denk gelirse
        if (bilinen != null && !bilinen.isEmpty()) {
            r = dene(s, son, SUPHELI, bilinen);
            if (r != null) return r;
            // 3) ayracsiz: satirin basi dogrudan bilinen bir ad olabilir
            //    ("JASON Gir su suya" -- OCR iki noktayi hic okumamis)
            r = ayracsiz(s, bilinen);
            if (r != null) return r;
        }

        return new Sonuc(null, s);
    }

    private static Sonuc dene(String s, int son, char[] ayraclar, Set<String> bilinen) {
        for (int i = 0; i < son; i++) {
            char c = s.charAt(i);
            if (!icinde(ayraclar, c)) continue;
            String ham = s.substring(0, i).trim();
            String kalan = s.substring(i + 1).trim();
            if (kalan.isEmpty()) continue;
            String ad = adTemizle(ham);
            if (ad == null) continue;
            if (bilinen != null && !bilinen.contains(sade(ad))) continue;
            return new Sonuc(ad, kalan);
        }
        return null;
    }

    /** Satirin basi dogrudan bilinen bir ad mi? En uzun eslesmeyi alir. */
    private static Sonuc ayracsiz(String s, Set<String> bilinen) {
        String[] kelimeler = s.split("\\s+");
        int enCok = Math.min(3, kelimeler.length - 1);
        for (int n = enCok; n >= 1; n--) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < n; i++) {
                if (i > 0) b.append(' ');
                b.append(kelimeler[i]);
            }
            String ham = b.toString();
            String ad = adTemizle(ham);
            if (ad == null) continue;
            if (!bilinen.contains(sade(ad))) continue;
            StringBuilder kalan = new StringBuilder();
            for (int i = n; i < kelimeler.length; i++) {
                if (i > n) kalan.append(' ');
                kalan.append(kelimeler[i]);
            }
            if (kalan.length() == 0) continue;
            return new Sonuc(ad, kalan.toString());
        }
        return null;
    }

    /**
     * Aday ad gecerli mi? Gecerliyse parantezli ek atilmis hali, degilse null.
     * "JASON (ON PHONE)" -> "JASON"
     */
    static String adTemizle(String ham) {
        if (ham == null) return null;
        String s = ham.trim();
        int par = s.indexOf('(');
        if (par > 0) s = s.substring(0, par).trim();
        if (s.length() < AD_EN_AZ || s.length() > AD_EN_COK) return null;

        int harf = 0, buyuk = 0, kelime = 1;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetter(c)) {
                harf++;
                if (Character.isUpperCase(c)) buyuk++;
            } else if (c == ' ') {
                kelime++;
            } else if (c != '.' && c != '\'' && c != '-') {
                return null;              // ad icinde olmamasi gereken karakter
            }
        }
        if (harf == 0) return null;
        if (kelime > 3) return null;
        // Oyunlar konusmaci adini buyuk harfle yazar; bu en guclu isaret.
        if (buyuk * 10 < harf * 6) return null;
        return s;
    }

    private static boolean icinde(char[] a, char c) {
        for (char x : a) if (x == c) return true;
        return false;
    }
}
